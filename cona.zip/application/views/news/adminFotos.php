<div class="container" style="margin-top: 50px">
    <a href="/sitecoop/index.php/admin/editarprojeto/<?php echo $id ?>">
        <button type="button" class="btn buttao-admin-white">Voltar</button>
    </a>
</div>
<div class="container">
    <fieldset>
        <legend>       <h2 style="font-family:'Aileron Light';color:white; text-align: right">Administração de Projetos</h2>
            <hr class="sublinhado-white">
            <h2 style="font-family:'Aileron Light';font-weight: bold;color:white; text-align: left">Fotos <?php echo $subtitulo ?></h2>
        </legend>
        <div class="row" style="">
            <?php for($i=0;$i<$filecount;$i++){
            $data['file'] = $ficheiros[$i];
            $data['tipo'] = $tipo;
            $data['id'] = $id;
            $data['i'] = $i;
            $this->load->view('news/modals/apagarFoto_modal', $data);?>
            <div class="col-sm-3" style="margin:5px" >
                <div class="hover-image"style="display: inline-block; position relative; ">
                    <img class="hover-image" height="200" width="250"  src="<?php echo base_url()?>/uploads/<?php echo $id ?>/<?php echo $tipo ?>/<?php echo $ficheiros[$i] ?>" >
                    <button class=" button-simples" data-toggle="modal" data-target="#apagar_foto_Modal<?php echo $i?>" style="position: absolute; right: 16px; top:0px;"><h6 style="color:whitesmoke;font-weight:bold;font-family: 'Aileron Light'">x</h6></button>
                </div>
            </div>
            <?php } ?>
        </div>
        <?php
        echo form_open_multipart("index.php/admin/$tipo/$id");?>

        <div>
            <div class="form-group">
                <div class="row colbox">
                    <div class="col-lg-4 col-sm-4">
                        <label for="localizacao" class="control-label">Adicionar Foto de menu</label>
                    </div>
                    <div class="col-lg-8 col-sm-8">
                        <input type="file" name="userfile" size="20" />
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12 col-sm-12 text-center">
                <input id="btn_login" name="btn_login" type="submit" class="btn buttao-admin-white" value="Submeter" />
            </div>
        </div>

    </fieldset>

    <?php echo form_close(); ?>
    <?php echo $this->session->flashdata('msg'); ?>
</div>