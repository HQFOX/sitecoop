<?php if($filecountc>0){?>
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
                <img class="d-block img-fluid" style="width: 100%; max-height: 550px" src="<?php echo base_url()?>/uploads/carrossel/<?php echo $ficheirosc[0];?>">
            </div>
            <?php for($i=1;$i<$filecountc;$i++){?>
                <div class="carousel-item">
                    <img class="d-block img-fluid" style="width: 100%; max-height: 550px" src="<?php echo base_url()?>/uploads/carrossel/<?php echo $ficheirosc[$i];?>">
                </div>
           <?php } ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
<?php } ?>
<div class="container" style="margin-bottom: 10%">



    <div id="sobre" class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-8" >
            <h2 style=" margin-top: 30%; margin-bottom:0; font-family:'Aileron Light';font-weight: bold;color:black;">Sobre a cooperativa</h2>
            <hr class="sublinhado" style="margin-bottom: 40px">
        </div>
    </div>
    <div class="row">
        <?php if(count($sobre)>0) echo $sobre[0]['sobre']; ?>
    </div>

    <div class="row">
        <div class="col-sm-5" style="margin:auto; text-align: center">
            <img style="max-height: 30%; max-width: 40%;margin-top: 30%; margin-bottom: 10%;" src="<?php echo base_url()?>/assets/images/logonobackground.png">
        </div>
    </div>
    <?php
    foreach ($post as $post):
        if($post['oculto']!=1){?>
    <div id="post" class="row">
        <div class="col-sm-8" style="margin:auto; text-align: left;">
            <h3 style=" margin-top: 30%; margin-bottom:0; font-family:'Aileron Light';font-weight: bold;color:black; text-align: left; resize: horizontal"><?php echo $post['titulo'];?></h3>
            <hr class="sublinhado" style=" height: 2px;">
            <h5 style="font-family:'Moon';font-weight: bold;color:black; text-align: right;"><?php echo $post['data'];?></h5>

            <?php if($post['imagem']!=''){

                foreach ($ficheirosp as $ficheiros):
                    if(strpos($ficheiros,$post['imagem'])!==false){?>
                        <img style="width: 100%;" src="<?php echo base_url()?>/uploads/post/<?php echo $ficheiros;?>">
                
            <?php   }
                endforeach;
            }
            
                echo $post['texto'];
                if($post['video']!='')
                    if($post['video']!="erro no link"){?>

                        <iframe width="100%" height="420" src="<?php echo $post['video'];?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                <?php }?>
        </div>
    </div>
        <?php }
    endforeach; ?>



</div>