<div class="container">
    <div class="row" style="margin-top: 5%">
         <div>
            <a href="/sitecoop/index.php/admin">
                <button type="button" class="btn buttao-admin-white">Voltar</button>
            </a>
        </div>
    </div>
    <div style="margin-top: 40px">
            <fieldset>
                <legend>
                    <h2 style="font-family:'Aileron Light';color:white; text-align: right">Administrar Página inicial</h2>
                    <hr class="sublinhado-white">
                    <h2 style="font-family:'Aileron Light';font-weight: bold;color:white; text-align: left">Carrossel</h2>
                </legend>
                <div class="row">
                <?php for($i=0;$i<$filecount;$i++){
                    $data['filename'] = $ficheiros[$i];
                    $this->load->view('news/modals/apagarCarrossel_modal', $data);?>
                    <div class="col-sm-3" style="margin:5px" >
                        <div class="hover-image"style="display: inline-block; position relative; ">
                            <img class="hover-image" height="200" width="250" src="<?php echo base_url()?>/uploads/carrossel/<?php echo $ficheiros[$i] ?>" >
                            <button class=" button-simples" data-toggle="modal" data-target="#apagar_carrossel_Modal" style="position: absolute; right: 16px; top:0px;"><h6 style="color:whitesmoke;font-weight:bold;font-family: 'Aileron Light'">x</h6></button>
                        </div>
                    </div>
                <?php } ?>
                <?php
                echo form_open_multipart("index.php/admin/addcarrossel");?>
                </div>
                <div class="form-group">
                    <div class="row colbox">
                        <div class="col-lg-4 col-sm-4" style="text-align: right;">
                            <label for="localizacao"   class="control-label">Adicionar Foto</label>
                        </div>
                        <div class="col-lg-8 col-sm-8">
                            <input type="file"  name="userfile" size="20" />
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12 text-center">
                        <input id="btn_login" name="btn_login" type="submit" class="btn buttao-admin-white" value="Submeter" />
                    </div>
                </div>
            </fieldset>
        <?php echo form_close(); ?>
        <?php echo $this->session->flashdata('msg'); ?>
    </div>
    <div style="margin-top: 40px">
        <?php
        echo form_open_multipart("index.php/admin/sobre");?>
        <fieldset>
            <legend>
                <hr class="sublinhado-white">
                <h2 style="font-family:'Aileron Light';font-weight: bold;color:white; text-align: left">Sobre Nós</h2>
            </legend>

            <div class="form-group">
                <div class="row colbox">

                    <div class="col-sm">
                        <div class="form-control" style="background-color: white">
                            <textarea id="sobre" name="sobre" value="<?php echo set_value('sobre'); ?>" ><?php echo $sobre[0]['sobre'] ?></textarea>
                            <script>
                                ClassicEditor
                                    .create( document.querySelector( '#sobre' ) )
                                    .catch( error => {
                                    console.error( error );
                                } );
                            </script>
                            <span class="text-danger"><?php echo form_error('sobre'); ?></span>
                        </div>
                    </div>
                </div>
            </div>



            <div class="form-group">
                <div class="col-lg-12 col-sm-12 text-center">
                    <input id="btn_login" name="btn_login" type="submit" class="btn buttao-admin-white" value="Submeter" />
                </div>
            </div>
        </fieldset>

        <?php echo form_close(); ?>
        <?php echo $this->session->flashdata('msg'); ?>
    </div>
</div>
